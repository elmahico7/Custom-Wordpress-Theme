<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'G0xC1vGp3rqu5dB3UrvMlg3xW5kUjhNT/pg2p9Corr+xALWo0gCpbrrbQlWDni/uWMzAx4phohfDqu4L4Bsthw==');
define('SECURE_AUTH_KEY',  'kbl61mQ07ew8Y5I3Eesvj1Po6NupMwt34kAt60gTp+TuyPMR0iCYiUx4F29Le1Vq50yjO890R0d51692P261tg==');
define('LOGGED_IN_KEY',    '11cy3hVrE5nTt4Os9sXdSjBZ9xuApPRVaQnSrrQsdMgdEF2yeUfD9RssQiB/OUjPJUL9IygFzJGwQrFOfW4zOA==');
define('NONCE_KEY',        'oTRcfLPQ/acpr5V7y22+VlaNCyyWURfDF20Y9S5MIFy1B9u9ZSIYelzkSNesY1mO+gCEDL9Sj7vyzzQYwt5xfQ==');
define('AUTH_SALT',        '7OLezkWBctVWy8s0qZeJpdSaFBe7Cm5S7mPvvzbD/etnrwZWHZIsUTPnyTMJyeIfmEKz8yU2MtXM/S7GGAoc+g==');
define('SECURE_AUTH_SALT', '/sscvcf8RYeq9NHY3Ki8R8ACV0jflx8L6jKtv7TVlM2ep2k7+kOoG0/1kmz+T2qx2Ixe8soxmdG1nsA13AdDIg==');
define('LOGGED_IN_SALT',   'hEQ6Qb1/7Xoj7zEHJzqucx/AXDGPEOpGiR1sCp8VNvgi6t6jZZKLa+Dy+0qnZ6fSvK5myvv/vmLiMzjt04QFqA==');
define('NONCE_SALT',       'AsWnW38KgSdel6/2v3LxIltgzffmn5yAuuO451rAiTMz9z1dS0Wd3OGXqRkldjZr9kIHy/ePqIu34WxKRdrXNg==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
